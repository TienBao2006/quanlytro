<?php
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=utf-8");

$conn = new mysqli("localhost", "root", "", "quan_ly_tro");
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Kết nối DB thất bại"]);
    exit;
}
$conn->set_charset("utf8mb4");

$landlord_id = trim($_GET['landlord_id'] ?? '');
if (empty($landlord_id)) {
    echo json_encode(["status" => "error", "message" => "Thiếu landlord_id"]);
    exit;
}

// Đảm bảo cột tồn tại
$conn->query("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS source VARCHAR(20) DEFAULT 'post'");
$conn->query("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS landlord_id VARCHAR(100) AFTER source");
$conn->query("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS room_number VARCHAR(50) AFTER user_id");
$conn->query("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS start_date VARCHAR(20) AFTER id_issue_date");
$conn->query("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS duration VARCHAR(20) AFTER start_date");

// Booking qua bài đăng
$sql1 = "SELECT b.id, b.post_id, COALESCE(b.user_id,'') as user_id,
                COALESCE(b.room_number,'') as room_number,
                b.full_name, b.phone, b.id_card, b.dob, b.id_issue_date,
                COALESCE(b.start_date,'') as start_date,
                COALESCE(b.duration,'') as duration,
                COALESCE(b.email,'') as email,
                COALESCE(b.address,'') as address,
                b.status, b.created_at,
                p.title AS post_title
         FROM bookings b
         JOIN posts p ON p.id = b.post_id
         LEFT JOIN users u ON u.phone = p.contact_phone
         WHERE COALESCE(u.uid, p.user_id) = ?
           AND COALESCE(b.source,'post') = 'post'";

// Booking trực tiếp (chủ trọ tự thêm)
$sql2 = "SELECT b.id, 0 as post_id, '' as user_id,
                COALESCE(b.room_number,'') as room_number,
                b.full_name, b.phone, b.id_card, b.dob, b.id_issue_date,
                COALESCE(b.start_date,'') as start_date,
                COALESCE(b.duration,'') as duration,
                COALESCE(b.email,'') as email,
                COALESCE(b.address,'') as address,
                b.status, b.created_at,
                'Thuê trực tiếp' AS post_title
         FROM bookings b
         WHERE b.source = 'direct' AND b.landlord_id = ?";

$bookings = [];

$stmt1 = $conn->prepare($sql1);
$stmt1->bind_param("s", $landlord_id);
$stmt1->execute();
$r1 = $stmt1->get_result();
while ($row = $r1->fetch_assoc()) $bookings[] = $row;
$stmt1->close();

$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param("s", $landlord_id);
$stmt2->execute();
$r2 = $stmt2->get_result();
while ($row = $r2->fetch_assoc()) $bookings[] = $row;
$stmt2->close();

// Sắp xếp: pending trước, rồi theo thời gian mới nhất
usort($bookings, function($a, $b) {
    $order = ['pending' => 0, 'confirmed' => 1, 'rejected' => 2];
    $oa = $order[$a['status']] ?? 3;
    $ob = $order[$b['status']] ?? 3;
    if ($oa !== $ob) return $oa - $ob;
    return strcmp($b['created_at'], $a['created_at']);
});

echo json_encode(["status" => "success", "bookings" => $bookings], JSON_UNESCAPED_UNICODE);
$conn->close();
