<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include 'db_config.php';

// Đảm bảo cột source tồn tại để phân biệt booking trực tiếp vs qua bài đăng
$conn->query("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS source VARCHAR(20) DEFAULT 'post'");
$conn->query("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS landlord_id VARCHAR(100) AFTER source");

$landlord_id   = trim($_POST['landlord_id']   ?? '');
$post_id       = intval($_POST['post_id']      ?? 0);
$full_name     = trim($_POST['full_name']      ?? '');
$phone         = trim($_POST['phone']          ?? '');
$id_card       = trim($_POST['id_card']        ?? '');
$dob           = trim($_POST['dob']            ?? '');
$id_issue_date = trim($_POST['id_issue_date']  ?? '');
$start_date    = trim($_POST['start_date']     ?? '');
$duration      = trim($_POST['duration']       ?? '');
$email         = trim($_POST['email']          ?? '');
$address       = trim($_POST['address']        ?? '');
$room_number   = trim($_POST['room_number']    ?? '');
$post_title    = trim($_POST['post_title']     ?? 'Thuê trực tiếp');

if (empty($landlord_id) || empty($full_name) || empty($phone) || empty($id_card) || empty($dob) || empty($id_issue_date)) {
    echo json_encode(["status" => "error", "message" => "Vui lòng điền đầy đủ thông tin bắt buộc"]);
    exit;
}

// Tìm hoặc tạo bài đăng ảo đại diện cho chủ trọ này (post_id = 0 không hợp lệ do FK)
// Dùng post_id = -1 trick: lưu trực tiếp vào bookings với post_id = 0 (không có FK constraint)
// Thực tế: bookings.post_id không có FOREIGN KEY nên có thể dùng 0
$stmt = $conn->prepare(
    "INSERT INTO bookings (post_id, user_id, room_number, full_name, phone, id_card, dob, id_issue_date, start_date, duration, email, address, source, landlord_id)
     VALUES (?, '', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'direct', ?)"
);
$stmt->bind_param(
    "isssssssssss",
    $post_id, $room_number, $full_name, $phone, $id_card, $dob, $id_issue_date,
    $start_date, $duration, $email, $address, $landlord_id
);

if ($stmt->execute()) {
    $booking_id = $conn->insert_id;
    // Tự động xác nhận luôn vì chủ trọ tự thêm
    $conn->query("UPDATE bookings SET status='confirmed' WHERE id=$booking_id");
    echo json_encode([
        "status"     => "success",
        "message"    => "Tạo booking trực tiếp thành công",
        "booking_id" => $booking_id,
        "post_title" => $post_title
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(["status" => "error", "message" => "Lỗi lưu dữ liệu: " . $stmt->error]);
}

$stmt->close();
$conn->close();
