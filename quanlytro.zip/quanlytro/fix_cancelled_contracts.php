<?php
header("Content-Type: application/json; charset=UTF-8");
include 'db_config.php';

// Tìm tất cả contract đã cancelled nhưng booking vẫn còn confirmed
$result = $conn->query("
    SELECT c.id as contract_id, c.booking_id, c.post_id
    FROM contracts c
    JOIN bookings b ON b.id = c.booking_id
    WHERE c.status = 'cancelled'
      AND b.status = 'confirmed'
");

$fixed = [];

while ($row = $result->fetch_assoc()) {
    $booking_id = (int)$row['booking_id'];
    $post_id    = (int)$row['post_id'];
    $contract_id = (int)$row['contract_id'];

    // Hủy booking
    $conn->query("UPDATE bookings SET status = 'cancelled' WHERE id = $booking_id");

    // Tính lại available_rooms
    $cnt_res = $conn->query("SELECT COUNT(*) as cnt FROM bookings WHERE post_id = $post_id AND status = 'confirmed'");
    $confirmed_count = $cnt_res ? (int)$cnt_res->fetch_assoc()['cnt'] : 0;

    $tr_res = $conn->query("SELECT COALESCE(total_rooms, available_rooms, 1) as tr FROM posts WHERE id = $post_id");
    $total_rooms = $tr_res ? (int)$tr_res->fetch_assoc()['tr'] : 1;

    $available_rooms = max(0, $total_rooms - $confirmed_count);
    $available = $available_rooms > 0 ? 1 : 0;

    $conn->query("UPDATE posts SET available_rooms = $available_rooms, available = $available WHERE id = $post_id");

    $fixed[] = [
        "contract_id"     => $contract_id,
        "booking_id"      => $booking_id,
        "post_id"         => $post_id,
        "available_rooms" => $available_rooms
    ];
}

echo json_encode(["status" => "success", "fixed" => $fixed], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
$conn->close();
