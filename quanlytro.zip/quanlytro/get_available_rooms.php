<?php
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include 'db_config.php';

$landlord_id = trim($_GET['landlord_id'] ?? '');
if (empty($landlord_id)) {
    echo json_encode(["status" => "error", "rooms" => []]);
    exit;
}

// Lấy tất cả bài đăng của chủ trọ
$stmt = $conn->prepare("
    SELECT p.id, p.title, COALESCE(p.total_rooms, p.available_rooms, 1) AS total_rooms
    FROM posts p
    LEFT JOIN users u ON u.phone = p.contact_phone
    WHERE COALESCE(u.uid, p.user_id) = ?
");
$stmt->bind_param("s", $landlord_id);
$stmt->execute();
$posts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (empty($posts)) {
    echo json_encode(["status" => "success", "rooms" => []]);
    exit;
}

$post_ids = array_column($posts, 'id');
$placeholders = implode(',', array_fill(0, count($post_ids), '?'));
$types = str_repeat('i', count($post_ids));

// Lấy các phòng đã bị chiếm (booking pending/confirmed hoặc có hợp đồng active)
$booked = []; // [post_id => [room_number, ...]]

// Từ bookings
$stmt2 = $conn->prepare("
    SELECT post_id, room_number FROM bookings
    WHERE post_id IN ($placeholders)
      AND status IN ('pending','confirmed')
      AND room_number != ''
");
$stmt2->bind_param($types, ...$post_ids);
$stmt2->execute();
$r2 = $stmt2->get_result();
while ($row = $r2->fetch_assoc()) {
    $booked[$row['post_id']][] = $row['room_number'];
}
$stmt2->close();

// Từ contracts active
$stmt3 = $conn->prepare("
    SELECT post_id, room_name FROM contracts
    WHERE post_id IN ($placeholders)
      AND status IN ('active','pending_tenant')
      AND room_name != ''
");
$stmt3->bind_param($types, ...$post_ids);
$stmt3->execute();
$r3 = $stmt3->get_result();
while ($row = $r3->fetch_assoc()) {
    $booked[$row['post_id']][] = $row['room_name'];
}
$stmt3->close();

// Tạo danh sách phòng còn trống
$rooms = [];
foreach ($posts as $post) {
    $pid = $post['id'];
    $total = intval($post['total_rooms']);
    $occupied = array_map('strval', $booked[$pid] ?? []);

    for ($i = 1; $i <= $total; $i++) {
        $room_num = (string)$i;
        if (!in_array($room_num, $occupied)) {
            $rooms[] = [
                "post_id"    => $pid,
                "post_title" => $post['title'],
                "room_number"=> $room_num,
                "label"      => $post['title'] . " - Phòng " . $room_num
            ];
        }
    }
}

echo json_encode(["status" => "success", "rooms" => $rooms], JSON_UNESCAPED_UNICODE);
$conn->close();
