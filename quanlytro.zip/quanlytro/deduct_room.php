<?php
error_reporting(0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=utf-8");

$conn = new mysqli("localhost", "root", "", "quan_ly_tro");
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Kết nối DB thất bại"]);
    exit;
}
$conn->set_charset("utf8mb4");

$post_id     = intval($_POST['post_id'] ?? 0);
$room_number = trim($_POST['room_number'] ?? '');

if (!$post_id || !$room_number) {
    echo json_encode(["status" => "error", "message" => "Thiếu post_id hoặc room_number"]);
    exit;
}

// Lấy available_rooms hiện tại
$res = $conn->query("SELECT available_rooms, COALESCE(total_rooms, available_rooms, 1) as total_rooms FROM posts WHERE id = $post_id");
if (!$res || !($row = $res->fetch_assoc())) {
    echo json_encode(["status" => "error", "message" => "Không tìm thấy bài đăng"]);
    exit;
}

$available_rooms = max(0, (int)$row['available_rooms'] - 1);
$available = $available_rooms > 0 ? 1 : 0;

$conn->query("UPDATE posts SET available_rooms = $available_rooms, available = $available WHERE id = $post_id");

echo json_encode(["status" => "success", "available_rooms" => $available_rooms]);
$conn->close();
